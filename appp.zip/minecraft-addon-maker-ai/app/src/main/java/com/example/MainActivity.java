package com.example;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.documentfile.provider.DocumentFile;

import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

import java.io.OutputStream;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {

    private AutoCompleteTextView providerSpinner;
    private TextInputLayout apiKeyLayout;
    private TextInputEditText apiKeyInput;
    private TextInputEditText promptInput;
    private TextInputEditText folderInput;
    private TextView responseText;
    private TextView statusText;
    private View progressBar;
    private View statusDot;
    private Button btnBrowse;
    private Button btnGenerate;
    private Button btnSave;

    private String selectedProvider = "Claude Proxy";
    private Uri selectedFolderUri = null;
    
    private SettingsManager settingsManager;
    private NetworkClient networkClient;

    private ExecutorService executorService = Executors.newSingleThreadExecutor();
    private Handler mainHandler = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        settingsManager = new SettingsManager(this);
        networkClient = new NetworkClient();

        providerSpinner = findViewById(R.id.providerSpinner);
        apiKeyLayout = findViewById(R.id.apiKeyLayout);
        apiKeyInput = findViewById(R.id.apiKeyInput);
        promptInput = findViewById(R.id.promptInput);
        folderInput = findViewById(R.id.folderInput);
        responseText = findViewById(R.id.responseText);
        statusText = findViewById(R.id.statusText);
        progressBar = findViewById(R.id.progressBar);
        statusDot = findViewById(R.id.statusDot);
        btnBrowse = findViewById(R.id.btnBrowse);
        btnGenerate = findViewById(R.id.btnGenerate);
        btnSave = findViewById(R.id.btnSave);

        String[] providers = new String[]{"Claude Proxy", "Mistral API", "OpenAI API"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_dropdown_item_1line, providers);
        providerSpinner.setAdapter(adapter);

        providerSpinner.setOnItemClickListener((parent, view, position, id) -> {
            selectedProvider = providers[position];
            if (selectedProvider.equals("Claude Proxy")) {
                apiKeyLayout.setVisibility(View.GONE);
            } else {
                apiKeyLayout.setVisibility(View.VISIBLE);
                String savedKey = settingsManager.getApiKey(selectedProvider);
                apiKeyInput.setText(savedKey);
            }
        });

        ActivityResultLauncher<Intent> folderPickerLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == Activity.RESULT_OK && result.getData() != null) {
                        selectedFolderUri = result.getData().getData();
                        if (selectedFolderUri != null) {
                            getContentResolver().takePersistableUriPermission(
                                    selectedFolderUri,
                                    Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                            );
                            DocumentFile documentFile = DocumentFile.fromTreeUri(this, selectedFolderUri);
                            folderInput.setText(documentFile != null ? documentFile.getName() : "Selected Folder");
                        }
                    }
                }
        );

        btnBrowse.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
            folderPickerLauncher.launch(intent);
        });

        btnGenerate.setOnClickListener(v -> generateCode());
        btnSave.setOnClickListener(v -> saveFiles());
    }

    private void setLoading(boolean loading) {
        btnGenerate.setEnabled(!loading);
        progressBar.setVisibility(loading ? View.VISIBLE : View.GONE);
        statusDot.setVisibility(loading ? View.GONE : View.VISIBLE);
        if (loading) {
            statusText.setText("PROCESSING...");
        } else {
            btnSave.setEnabled(!responseText.getText().toString().isEmpty());
        }
    }

    private void generateCode() {
        String prompt = promptInput.getText() != null ? promptInput.getText().toString().trim() : "";
        String apiKey = apiKeyInput.getText() != null ? apiKeyInput.getText().toString().trim() : "";

        if (prompt.isEmpty()) {
            Toast.makeText(this, "Prompt is required", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!selectedProvider.equals("Claude Proxy")) {
            if (apiKey.isEmpty()) {
                Toast.makeText(this, "API Key is required for " + selectedProvider, Toast.LENGTH_SHORT).show();
                return;
            }
            settingsManager.saveApiKey(selectedProvider, apiKey);
        }

        setLoading(true);
        responseText.setText("");

        executorService.execute(() -> {
            try {
                String result = networkClient.generateCode(selectedProvider, prompt, apiKey);

                mainHandler.post(() -> {
                    setLoading(false);
                    statusText.setText("GENERATION SUCCESSFUL");
                    responseText.setText(result);
                });
            } catch (Exception e) {
                mainHandler.post(() -> {
                    setLoading(false);
                    statusText.setText("ERROR: " + e.getMessage());
                    e.printStackTrace();
                });
            }
        });
    }

    private void saveFiles() {
        if (selectedFolderUri == null) {
            Toast.makeText(this, "Please select a destination folder first.", Toast.LENGTH_SHORT).show();
            return;
        }

        String text = responseText.getText().toString();
        if (text.isEmpty()) {
            Toast.makeText(this, "No code to save.", Toast.LENGTH_SHORT).show();
            return;
        }

        setLoading(true);
        statusText.setText("SAVING FILES...");

        executorService.execute(() -> {
            try {
                DocumentFile documentFile = DocumentFile.fromTreeUri(MainActivity.this, selectedFolderUri);
                if (documentFile == null) throw new Exception("Could not access selected folder");

                List<FileProcessor.FileToSave> files = FileProcessor.extractCodeBlocks(text);

                for (FileProcessor.FileToSave file : files) {
                    DocumentFile newFile = documentFile.createFile("text/plain", file.name);
                    if (newFile != null) {
                        try (OutputStream stream = getContentResolver().openOutputStream(newFile.getUri())) {
                            if (stream != null) {
                                stream.write(file.content.getBytes());
                            }
                        }
                    }
                }

                mainHandler.post(() -> {
                    setLoading(false);
                    statusText.setText("FILES SAVED SUCCESSFULLY");
                    Toast.makeText(MainActivity.this, "Files saved", Toast.LENGTH_SHORT).show();
                });
            } catch (Exception e) {
                mainHandler.post(() -> {
                    setLoading(false);
                    statusText.setText("ERROR SAVING FILES");
                    Toast.makeText(MainActivity.this, "Error saving files: " + e.getMessage(), Toast.LENGTH_LONG).show();
                });
            }
        });
    }
}
