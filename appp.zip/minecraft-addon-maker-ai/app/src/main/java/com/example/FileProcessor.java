package com.example;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class FileProcessor {
    
    public static class FileToSave {
        public String name;
        public String content;

        public FileToSave(String name, String content) {
            this.name = name;
            this.content = content;
        }
    }

    public static List<FileToSave> extractCodeBlocks(String text) {
        List<FileToSave> list = new ArrayList<>();
        // Simple regex to extract code blocks ```language\n code \n```
        Pattern pattern = Pattern.compile("```(\\w*)\\n([\\s\\S]*?)```");
        Matcher matcher = pattern.matcher(text);

        int count = 1;
        while (matcher.find()) {
            String lang = matcher.group(1);
            String content = matcher.group(2);
            if (content != null) {
                String ext = (lang != null && !lang.isEmpty()) ? "." + lang : ".txt";
                list.add(new FileToSave("generated_code_" + count + ext, content.trim()));
                count++;
            }
        }

        if (list.isEmpty()) {
            list.add(new FileToSave("generated_response.txt", text));
        }

        return list;
    }
}
