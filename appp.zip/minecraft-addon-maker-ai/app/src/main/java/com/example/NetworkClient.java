package com.example;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.net.URLEncoder;
import java.util.concurrent.TimeUnit;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class NetworkClient {
    private OkHttpClient client = new OkHttpClient.Builder()
            .readTimeout(60, TimeUnit.SECONDS)
            .connectTimeout(60, TimeUnit.SECONDS)
            .build();

    public String generateCode(String provider, String prompt, String apiKey) throws Exception {
        if ("Claude Proxy".equals(provider)) {
            return callClaudeProxy(prompt);
        } else if ("Mistral API".equals(provider)) {
            return callMistral(prompt, apiKey);
        } else if ("OpenAI API".equals(provider)) {
            return callOpenAi(prompt, apiKey);
        }
        throw new IllegalArgumentException("Unknown Provider");
    }

    private String callClaudeProxy(String prompt) throws Exception {
        String encodedPrompt = URLEncoder.encode(prompt, "UTF-8");
        String url = "https://kakarotai.rf.gd/api/opus4.7/api.php?question=" + encodedPrompt;

        Request request = new Request.Builder()
                .url(url)
                .get()
                .build();

        try (Response response = client.newCall(request).execute()) {
            if (!response.isSuccessful()) throw new IOException("Unexpected code " + response);
            String result = response.body().string();
            
            try {
                JSONObject json = new JSONObject(result);
                if (json.has("response")) {
                    return json.getString("response");
                } else if (json.has("choices")) {
                    return json.getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content");
                }
            } catch (Exception e) {
                // Return raw string if JSON parsing fails
            }
            return result;
        }
    }

    private String callMistral(String prompt, String apiKey) throws Exception {
        String url = "https://api.mistral.ai/v1/chat/completions";
        JSONObject requestBody = new JSONObject();
        requestBody.put("model", "mistral-small-latest");
        
        JSONArray messages = new JSONArray();
        JSONObject message = new JSONObject();
        message.put("role", "user");
        message.put("content", prompt);
        messages.put(message);
        requestBody.put("messages", messages);

        RequestBody body = RequestBody.create(requestBody.toString(), MediaType.parse("application/json; charset=utf-8"));
        Request request = new Request.Builder()
                .url(url)
                .addHeader("Authorization", "Bearer " + apiKey)
                .post(body)
                .build();

        try (Response response = client.newCall(request).execute()) {
            if (!response.isSuccessful()) throw new IOException("Failed Mistral API call: " + response.message());
            String result = response.body().string();
            JSONObject json = new JSONObject(result);
            return json.getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content");
        }
    }

    private String callOpenAi(String prompt, String apiKey) throws Exception {
        String url = "https://api.openai.com/v1/chat/completions";
        JSONObject requestBody = new JSONObject();
        requestBody.put("model", "gpt-3.5-turbo");
        
        JSONArray messages = new JSONArray();
        JSONObject message = new JSONObject();
        message.put("role", "user");
        message.put("content", prompt);
        messages.put(message);
        requestBody.put("messages", messages);

        RequestBody body = RequestBody.create(requestBody.toString(), MediaType.parse("application/json; charset=utf-8"));
        Request request = new Request.Builder()
                .url(url)
                .addHeader("Authorization", "Bearer " + apiKey)
                .post(body)
                .build();

        try (Response response = client.newCall(request).execute()) {
            if (!response.isSuccessful()) throw new IOException("Failed OpenAI API call: " + response.message());
            String result = response.body().string();
            JSONObject json = new JSONObject(result);
            return json.getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content");
        }
    }
}
