package com.example;

import android.content.Context;
import android.content.SharedPreferences;

public class SettingsManager {
    private static final String PREFS_NAME = "settings";
    private SharedPreferences sharedPreferences;

    public SettingsManager(Context context) {
        sharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }

    public String getApiKey(String providerName) {
        return sharedPreferences.getString(providerName, "");
    }

    public void saveApiKey(String providerName, String apiKey) {
        sharedPreferences.edit().putString(providerName, apiKey).apply();
    }
}
