package com.example

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "settings")

class SettingsRepository(private val context: Context) {
    companion object {
        val MISTRAL_KEY = stringPreferencesKey("mistral_key")
        val OPENAI_KEY = stringPreferencesKey("openai_key")
    }

    val mistralKeyFlow: Flow<String> = context.dataStore.data
        .map { preferences ->
            preferences[MISTRAL_KEY] ?: ""
        }

    val openaiKeyFlow: Flow<String> = context.dataStore.data
        .map { preferences ->
            preferences[OPENAI_KEY] ?: ""
        }

    suspend fun saveMistralKey(key: String) {
        context.dataStore.edit { preferences ->
            preferences[MISTRAL_KEY] = key
        }
    }

    suspend fun saveOpenAiKey(key: String) {
        context.dataStore.edit { preferences ->
            preferences[OPENAI_KEY] = key
        }
    }
}
