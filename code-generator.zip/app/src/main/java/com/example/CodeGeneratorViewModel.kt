package com.example

import android.app.Application
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class CodeGeneratorViewModel(application: Application) : AndroidViewModel(application) {
    private val settingsRepo = SettingsRepository(application)
    private val networkHelper = NetworkHelper()

    val selectedProvider = MutableStateFlow(AiProvider.CLAUDE_PROXY)
    val apiKeyInput = MutableStateFlow("")
    val promptInput = MutableStateFlow("")
    val selectedFolderUri = MutableStateFlow<Uri?>(null)
    val selectedFolderName = MutableStateFlow("No folder selected")
    
    val responseText = MutableStateFlow("")
    val isLoading = MutableStateFlow(false)
    val statusMessage = MutableStateFlow("")

    val apiKeysFlow = combine(
        settingsRepo.mistralKeyFlow,
        settingsRepo.openaiKeyFlow
    ) { mistral, openai -> Pair(mistral, openai) }

    init {
        viewModelScope.launch {
            apiKeysFlow.collect { (mistralKey, openaiKey) ->
                when (selectedProvider.value) {
                    AiProvider.MISTRAL -> apiKeyInput.value = mistralKey
                    AiProvider.OPENAI -> apiKeyInput.value = openaiKey
                    AiProvider.CLAUDE_PROXY -> { /* no-op */ }
                }
            }
        }
    }

    fun onProviderSelected(provider: AiProvider, mistralKey: String, openaiKey: String) {
        selectedProvider.value = provider
        when (provider) {
            AiProvider.MISTRAL -> apiKeyInput.value = mistralKey
            AiProvider.OPENAI -> apiKeyInput.value = openaiKey
            else -> apiKeyInput.value = ""
        }
    }

    fun onApiKeyChanged(key: String) {
        apiKeyInput.value = key
        viewModelScope.launch {
            when (selectedProvider.value) {
                AiProvider.MISTRAL -> settingsRepo.saveMistralKey(key)
                AiProvider.OPENAI -> settingsRepo.saveOpenAiKey(key)
                else -> {}
            }
        }
    }

    fun onFolderSelected(uri: Uri?) {
        if (uri == null) return
        selectedFolderUri.value = uri
        
        val context = getApplication<Application>()
        try {
            val docFile = DocumentFile.fromTreeUri(context, uri)
            selectedFolderName.value = docFile?.name ?: "Selected Folder"
        } catch (e: Exception) {
            selectedFolderName.value = "Selected Folder"
        }
    }

    fun generateCode() {
        val prompt = promptInput.value.trim()
        val provider = selectedProvider.value
        val key = apiKeyInput.value.trim()

        if (prompt.isEmpty()) {
            statusMessage.value = "Prompt cannot be empty"
            return
        }

        if (provider != AiProvider.CLAUDE_PROXY && key.isEmpty()) {
            statusMessage.value = "API Key required for ${provider.displayName}"
            return
        }

        viewModelScope.launch {
            isLoading.value = true
            statusMessage.value = "Generating code..."
            responseText.value = ""
            
            try {
                val result = networkHelper.generateCode(provider, prompt, key)
                responseText.value = result
                statusMessage.value = "Generation successful"
            } catch (e: Exception) {
                statusMessage.value = "Error: ${e.message}"
                e.printStackTrace()
            } finally {
                isLoading.value = false
            }
        }
    }

    fun saveFiles() {
        val folderUri = selectedFolderUri.value
        val text = responseText.value

        if (folderUri == null) {
            statusMessage.value = "Please select a destination folder first."
            return
        }
        if (text.isEmpty()) {
            statusMessage.value = "No code to save."
            return
        }

        viewModelScope.launch {
            isLoading.value = true
            statusMessage.value = "Saving files..."
            
            val context = getApplication<Application>()
            try {
                withContext(Dispatchers.IO) {
                    val filesToSave = extractCodeBlocks(text)
                    val documentFile = DocumentFile.fromTreeUri(context, folderUri) 
                        ?: throw Exception("Could not access selected folder")

                    for ((fileName, content) in filesToSave) {
                        val safeName = fileName.replace(Regex("[^a-zA-Z0-9.\\-_]"), "_")
                        val fileDoc = documentFile.createFile("text/plain", safeName) 
                            ?: throw Exception("Failed to create file $safeName")
                            
                        context.contentResolver.openOutputStream(fileDoc.uri)?.use { stream ->
                            stream.write(content.toByteArray())
                        }
                    }
                }
                statusMessage.value = "Files saved successfully!"
            } catch (e: Exception) {
                statusMessage.value = "Error saving files: ${e.message}"
                e.printStackTrace()
            } finally {
                isLoading.value = false
            }
        }
    }

    private fun extractCodeBlocks(text: String): List<Pair<String, String>> {
        val regex = Regex("```(\\w*)\\n([\\s\\S]*?)```")
        val matches = regex.findAll(text).toList()
        
        if (matches.isEmpty()) {
            return listOf("generated_response.txt" to text)
        }

        return matches.mapIndexed { index, result ->
            val lang = result.groupValues[1]
            val ext = if (lang.isNotEmpty()) ".$lang" else ".txt"
            val code = result.groupValues[2].trim()
            val filename = "generated_code_${index + 1}$ext"
            filename to code
        }
    }
}
