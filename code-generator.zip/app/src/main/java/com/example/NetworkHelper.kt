package com.example

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.URLEncoder
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

enum class AiProvider(val displayName: String) {
    CLAUDE_PROXY("Claude Proxy"),
    MISTRAL("Mistral API"),
    OPENAI("OpenAI API")
}

class NetworkHelper {
    private val client = OkHttpClient.Builder()
        .readTimeout(60, TimeUnit.SECONDS)
        .connectTimeout(60, TimeUnit.SECONDS)
        .build()

    suspend fun generateCode(
        provider: AiProvider,
        prompt: String,
        apiKey: String
    ): String = withContext(Dispatchers.IO) {
        when (provider) {
            AiProvider.CLAUDE_PROXY -> callClaudeProxy(prompt)
            AiProvider.MISTRAL -> callMistral(prompt, apiKey)
            AiProvider.OPENAI -> callOpenAi(prompt, apiKey)
        }
    }

    private fun callClaudeProxy(prompt: String): String {
        // According to prompt: Claude Proxy (Free, no API key needed) - Endpoint: https://kakarotai.rf.gp/api/opus4.7/api.php
        // Some proxies prefer POST or GET. Let's try GET since `api.php` often handles `?message=...` parameters.
        val encodedPrompt = URLEncoder.encode(prompt, "UTF-8")
        val url = "https://kakarotai.rf.gd/api/opus4.7/api.php?message=$encodedPrompt"
        
        val request = Request.Builder()
            .url(url)
            .get()
            .build()
            
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) throw IOException("Unexpected code $response")
            val result = response.body?.string() ?: ""
            // The proxy might return JSON, let's try to extract from a generic text response or return directly.
            return try {
                val json = JSONObject(result)
                if (json.has("response")) {
                    json.getString("response")
                 } else if (json.has("choices")) {
                    json.getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
                 } else {
                    result
                 }
            } catch (e: Exception) {
                result // Return raw if it's not JSON
            }
        }
    }

    private fun callMistral(prompt: String, apiKey: String): String {
        val url = "https://api.mistral.ai/v1/chat/completions"
        val requestBody = JSONObject().apply {
            put("model", "mistral-small-latest") // standard reliable model
            val messages = JSONArray()
            messages.put(JSONObject().apply {
                put("role", "user")
                put("content", prompt)
            })
            put("messages", messages)
        }.toString()

        val body = requestBody.toRequestBody("application/json; charset=utf-8".toMediaType())
        val request = Request.Builder()
            .url(url)
            .addHeader("Authorization", "Bearer $apiKey")
            .post(body)
            .build()
            
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) throw IOException("Failed Mistral API call: ${response.message}")
            val result = response.body?.string() ?: throw IOException("Empty response")
            val json = JSONObject(result)
            return json.getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
        }
    }

    private fun callOpenAi(prompt: String, apiKey: String): String {
        val url = "https://api.openai.com/v1/chat/completions"
        val requestBody = JSONObject().apply {
            put("model", "gpt-3.5-turbo")
            val messages = JSONArray()
            messages.put(JSONObject().apply {
                put("role", "user")
                put("content", prompt)
            })
            put("messages", messages)
        }.toString()

        val body = requestBody.toRequestBody("application/json; charset=utf-8".toMediaType())
        val request = Request.Builder()
            .url(url)
            .addHeader("Authorization", "Bearer $apiKey")
            .post(body)
            .build()
            
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) throw IOException("Failed OpenAI API call: ${response.message}")
            val result = response.body?.string() ?: throw IOException("Empty response")
            val json = JSONObject(result)
            return json.getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
        }
    }
}
