package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val Background = Color(0xFFFDFCFF)
val OnBackground = Color(0xFF1A1C1E)

val Primary = Color(0xFF005AC1)
val OnPrimary = Color(0xFFFFFFFF)
val PrimaryContainer = Color(0xFFD1E4FF)
val OnPrimaryContainer = Color(0xFF001D36)

val Surface = Color(0xFFFDFCFF)
val OnSurface = Color(0xFF1A1C1E)

val SurfaceVariant = Color(0xFFF3F4F9)
val OnSurfaceVariant = Color(0xFF44474E)

val Outline = Color(0xFF757780)
val OutlineVariant = Color(0xFFE1E2EC)

val SuccessGreen = Color(0xFF34A853)

val CodeBackground = Color(0xFF1A1C1E)
val CodeText = Color(0xFFE1E2EC)
val CodeHighlight = Color(0xFFC4E7FF)
val CodeKeyword = Color(0xFFA8C7FA)
val CodeComment = Color(0xFF8E918F)

val DarkBackground = Color(0xFF1A1C1E)
val DarkOnBackground = Color(0xFFE1E2EC)

val DarkPrimary = Color(0xFFA8C7FA)
val DarkOnPrimary = Color(0xFF003062)
val DarkPrimaryContainer = Color(0xFF00479A)
val DarkOnPrimaryContainer = Color(0xFFD1E4FF)

val DarkSurface = Color(0xFF1A1C1E)
val DarkOnSurface = Color(0xFFE1E2EC)

val DarkSurfaceVariant = Color(0xFF44474E)
val DarkOnSurfaceVariant = Color(0xFFC4C6D0)

val DarkOutline = Color(0xFF8E9099)
val DarkOutlineVariant = Color(0xFF44474E)

val DarkSuccessGreen = Color(0xFF81C995)