package com.kakarot.ui.theme

import androidx.compose.ui.graphics.Color

val BackgroundDark = Color(0xFF0F172A)
val SurfaceDark = Color(0xFF1E293B)
val PrimaryAI = Color(0xFF6366F1)
val SecondaryAI = Color(0xFFA855F7)
val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val ModelBubbleBg = Color(0x331E293B)
val ModelBubbleBorder = Color(0x1AFFFFFF)
val StatusGreen = Color(0xFF10B981)

