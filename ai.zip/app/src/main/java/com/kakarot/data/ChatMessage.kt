package com.kakarot.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

@Entity(tableName = "chat_messages")
data class ChatMessage(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val role: String, // "user" or "model"
    val content: String,
    val modelUsed: String, // To know which model answered
    val timestamp: Long = System.currentTimeMillis()
)
