package com.kakarot

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.kakarot.ui.ChatScreen
import com.kakarot.ui.theme.MyApplicationTheme
import com.kakarot.viewmodel.ChatViewModel
import com.kakarot.viewmodel.ChatViewModelFactory

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      MyApplicationTheme {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = MaterialTheme.colorScheme.background
        ) {
            val chatViewModel: ChatViewModel = viewModel(
                factory = ChatViewModelFactory(applicationContext)
            )
            ChatScreen(viewModel = chatViewModel)
        }
      }
    }
  }
}

