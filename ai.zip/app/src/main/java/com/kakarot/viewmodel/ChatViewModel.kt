package com.kakarot.viewmodel

import android.content.Context
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.kakarot.BuildConfig
import com.kakarot.data.AppDatabase
import com.kakarot.data.ChatDao
import com.kakarot.data.ChatMessage
import com.kakarot.model.AiModel
import com.kakarot.model.getSystemPrompt
import com.kakarot.network.Candidate
import com.kakarot.network.Content
import com.kakarot.network.GenerateContentRequest
import com.kakarot.network.Part
import com.kakarot.network.RetrofitClient
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class ChatViewModel(private val chatDao: ChatDao) : ViewModel() {

    val messages: StateFlow<List<ChatMessage>> = chatDao.getAllMessages()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    private val _selectedModel = MutableStateFlow(AiModel.DEEPSEEK_V3_1)
    val selectedModel: StateFlow<AiModel> = _selectedModel.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    fun selectModel(model: AiModel) {
        _selectedModel.value = model
    }

    fun sendMessage(text: String) {
        if (text.isBlank()) return

        val userMessage = ChatMessage(
            role = "user",
            content = text,
            modelUsed = _selectedModel.value.displayName
        )

        viewModelScope.launch {
            chatDao.insertMessage(userMessage)
            _isLoading.value = true

            try {
                val apiKey = BuildConfig.GEMINI_API_KEY
                
                // Get chat history for context
                val history = messages.value.takeLast(10).mapNotNull {
                    if (it.role == "user") {
                        Content(role = "user", parts = listOf(Part(text = it.content)))
                    } else {
                        Content(role = "model", parts = listOf(Part(text = it.content)))
                    }
                }.toMutableList()

                history.add(Content(role = "user", parts = listOf(Part(text = text))))

                val request = GenerateContentRequest(
                    contents = history,
                    systemInstruction = Content(
                        parts = listOf(Part(text = getSystemPrompt(_selectedModel.value)))
                    )
                )

                val response = RetrofitClient.service.generateContent(apiKey, request)
                val replyText = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                    ?: "Error: I'm currently unable to reply."

                val modelMessage = ChatMessage(
                    role = "model",
                    content = replyText,
                    modelUsed = _selectedModel.value.displayName
                )
                chatDao.insertMessage(modelMessage)

            } catch (e: Exception) {
                Log.e("ChatViewModel", "Error fetching from API", e)
                val errorMessage = ChatMessage(
                    role = "model",
                    content = "Connection error. Please check your API key in Settings.",
                    modelUsed = _selectedModel.value.displayName
                )
                chatDao.insertMessage(errorMessage)
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun clearChat() {
        viewModelScope.launch {
            chatDao.clearHistory()
        }
    }
}

class ChatViewModelFactory(private val context: Context) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(ChatViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return ChatViewModel(AppDatabase.getDatabase(context).chatDao()) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
